Make sure you have installed this library

stweet
pandas
numpy 
matplotlib 
yfinance 
scikit-learn 
wordcloud 
textblob 